<section>
    <div class="">
        <section class="les_partenaies ">
            <div class="">
                <div class="owl-carousel" data-dots="false" data-autoplay="true" data-slides-to-show="12">
                    <div>
                        <a href="/listing/red">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/1.jpg" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/sigma">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/3.jpg" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/canoon">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/2.png" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/dji">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/5.png" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/steadicam">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/7.png" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/tilta">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/8.png" class='dklzl' />
                        </a>
                    </div>
                    <div>
                        <a href="/listing/atomos">
                            <img src="<?php echo get_template_directory_uri();?>/assets/images/partners/6.png" class='dklzl' />
                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>
</section>