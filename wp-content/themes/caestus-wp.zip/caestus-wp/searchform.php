    <form class="mt-30" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" role="search">
        <input type="text" name="s" placeholder="Search">
        <button type="type"><i class="fas fa-search"></i></a></button>
    </form>