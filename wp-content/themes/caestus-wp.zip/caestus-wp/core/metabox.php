<?php

/*
*   Security : Deny Direct Url Access
*/
if(!defined('ABSPATH')) {
    exit;
}


require_once 'metaboxes/page.php';
