<!-- محتوى الفوتر -->

<?php if ( is_active_sidebar( 'footer_widgets_1' ) ) : ?>
<?php dynamic_sidebar( 'footer_widgets_1' ); ?>
<?php endif; ?>


<?php if ( is_active_sidebar( 'footer_widgets_2' ) ) : ?>
<?php dynamic_sidebar( 'footer_widgets_2' ); ?>
<?php endif; ?>


<?php if ( is_active_sidebar( 'footer_widgets_3' ) ) : ?>
<?php dynamic_sidebar( 'footer_widgets_3' ); ?>
<?php endif; ?>