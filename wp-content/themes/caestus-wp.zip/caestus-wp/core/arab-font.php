<?php 

$fonts = array(
    [
    'name' => 'iransans',
    'link' => 'www.google.com',
    'font-family' => ''
    ],
    [
    'name' => 'iransans2',
    'link' => 'https://fonts.googleapis.com/css?family=Cairo',
    'font-family' => ''
    ],      
    [
    'name' => 'iransans3',
    'link' => 'https://www.fontstatic.com/f=flat-jooza',
    'font-family' => ''
    ],    
    [
    'name' => 'iransans4',
    'link' => 'http://fonts.googleapis.com/earlyaccess/amiri.css',
    'font-family' => ''
    ],      
    [
    'name' => 'iransans5',
    'link' => 'https://fonts.googleapis.com/earlyaccess/droidarabickufi.css',
    'font-family' => ''
    ],   
    [
    'name' => 'iransans6',
    'link' => 'https://static.hsoubcdn.com/assets/fonts/css/NotoArabic.css',
    'font-family' => ''
    ]   
);

//www.fontstatic.com/f=dubai-light