<!-- Google Captcha -->
<script src="<?php echo get_template_directory_uri();?>/assets/js/lib/api.js?render=6LelLcoUAAAAABQsni4zy4zsn3xdOdRAeMsKELmB"></script>
<?php wp_footer(); ?>